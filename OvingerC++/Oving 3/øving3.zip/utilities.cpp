#include "std_lib_facilities.h"
int randomWithLimits(int low, int high){
    assert(high > low);
    if(rand() == 16807){
        srand(static_cast<unsigned int>(time(nullptr)));
    }
    int tilfeldig_tall;
    tilfeldig_tall = (rand() % (high-low))+low;
    return tilfeldig_tall;
}
